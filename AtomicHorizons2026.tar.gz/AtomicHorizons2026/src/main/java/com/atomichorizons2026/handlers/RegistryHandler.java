package com.atomichorizons2026.handlers;

import com.atomichorizons2026.AtomicHorizons2026;
import com.atomichorizons2026.blocks.BlockBase;
import com.atomichorizons2026.blocks.BlockOre;
import com.atomichorizons2026.blocks.BlockSMRCore;
import com.atomichorizons2026.items.ItemBase;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@EventBusSubscriber
public class RegistryHandler {
    
    // Blocks
    public static Block ORE_URANIUM;
    public static Block ORE_THORIUM;
    public static Block ORE_ZIRCONIUM;
    public static Block BLOCK_GRAPHITE;
    public static Block BLOCK_LEAD;
    public static Block BLOCK_STEEL;
    public static Block SMR_CORE;
    public static Block SMR_CASING;
    
    // Items
    public static Item RAW_URANIUM;
    public static Item HALEU;
    public static Item TRISO_PARTICLES;
    public static Item INGOT_THORIUM;
    public static Item INGOT_ZIRCONIUM;
    public static Item INGOT_LEAD;
    public static Item INGOT_STEEL;
    public static Item INGOT_GRAPHITE;
    public static Item FUEL_ROD_HALEU;
    public static Item SPENT_FUEL_ROD;
    public static Item HAZMAT_SPRAY;
    public static Item POTASSIUM_IODIDE;
    
    public static void preInitRegistries() {
        // Initialize blocks
        ORE_URANIUM = new BlockOre("ore_uranium", 3, 15.0f, 3);
        ORE_THORIUM = new BlockOre("ore_thorium", 3, 12.0f, 3);
        ORE_ZIRCONIUM = new BlockOre("ore_zirconium", 2, 10.0f, 2);
        BLOCK_GRAPHITE = new BlockBase("block_graphite", Material.IRON, 5.0f, 2);
        BLOCK_LEAD = new BlockBase("block_lead", Material.IRON, 8.0f, 2);
        BLOCK_STEEL = new BlockBase("block_steel", Material.IRON, 10.0f, 2);
        SMR_CORE = new BlockSMRCore("smr_core");
        SMR_CASING = new BlockBase("smr_casing", Material.IRON, 15.0f, 2);
        
        // Initialize items
        RAW_URANIUM = new ItemBase("raw_uranium");
        HALEU = new ItemBase("haleu");
        TRISO_PARTICLES = new ItemBase("triso_particles");
        INGOT_THORIUM = new ItemBase("ingot_thorium");
        INGOT_ZIRCONIUM = new ItemBase("ingot_zirconium");
        INGOT_LEAD = new ItemBase("ingot_lead");
        INGOT_STEEL = new ItemBase("ingot_steel");
        INGOT_GRAPHITE = new ItemBase("ingot_graphite");
        FUEL_ROD_HALEU = new ItemBase("fuel_rod_haleu");
        SPENT_FUEL_ROD = new ItemBase("spent_fuel_rod");
        HAZMAT_SPRAY = new ItemBase("hazmat_spray");
        POTASSIUM_IODIDE = new ItemBase("potassium_iodide");
    }
    
    public static void initRegistries() {
        // Register recipes here
    }
    
    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll(
            ORE_URANIUM,
            ORE_THORIUM,
            ORE_ZIRCONIUM,
            BLOCK_GRAPHITE,
            BLOCK_LEAD,
            BLOCK_STEEL,
            SMR_CORE,
            SMR_CASING
        );
        
        // Register tile entities
        GameRegistry.registerTileEntity(((BlockSMRCore)SMR_CORE).getTileEntityClass(), SMR_CORE.getRegistryName());
    }
    
    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        // Register item blocks
        event.getRegistry().registerAll(
            new ItemBlock(ORE_URANIUM).setRegistryName(ORE_URANIUM.getRegistryName()),
            new ItemBlock(ORE_THORIUM).setRegistryName(ORE_THORIUM.getRegistryName()),
            new ItemBlock(ORE_ZIRCONIUM).setRegistryName(ORE_ZIRCONIUM.getRegistryName()),
            new ItemBlock(BLOCK_GRAPHITE).setRegistryName(BLOCK_GRAPHITE.getRegistryName()),
            new ItemBlock(BLOCK_LEAD).setRegistryName(BLOCK_LEAD.getRegistryName()),
            new ItemBlock(BLOCK_STEEL).setRegistryName(BLOCK_STEEL.getRegistryName()),
            new ItemBlock(SMR_CORE).setRegistryName(SMR_CORE.getRegistryName()),
            new ItemBlock(SMR_CASING).setRegistryName(SMR_CASING.getRegistryName())
        );
        
        // Register items
        event.getRegistry().registerAll(
            RAW_URANIUM,
            HALEU,
            TRISO_PARTICLES,
            INGOT_THORIUM,
            INGOT_ZIRCONIUM,
            INGOT_LEAD,
            INGOT_STEEL,
            INGOT_GRAPHITE,
            FUEL_ROD_HALEU,
            SPENT_FUEL_ROD,
            HAZMAT_SPRAY,
            POTASSIUM_IODIDE
        );
    }
    
    @SideOnly(Side.CLIENT)
    public static void registerModels() {
        // Register block models
        registerBlockModel(ORE_URANIUM);
        registerBlockModel(ORE_THORIUM);
        registerBlockModel(ORE_ZIRCONIUM);
        registerBlockModel(BLOCK_GRAPHITE);
        registerBlockModel(BLOCK_LEAD);
        registerBlockModel(BLOCK_STEEL);
        registerBlockModel(SMR_CORE);
        registerBlockModel(SMR_CASING);
        
        // Register item models
        registerItemModel(RAW_URANIUM);
        registerItemModel(HALEU);
        registerItemModel(TRISO_PARTICLES);
        registerItemModel(INGOT_THORIUM);
        registerItemModel(INGOT_ZIRCONIUM);
        registerItemModel(INGOT_LEAD);
        registerItemModel(INGOT_STEEL);
        registerItemModel(INGOT_GRAPHITE);
        registerItemModel(FUEL_ROD_HALEU);
        registerItemModel(SPENT_FUEL_ROD);
        registerItemModel(HAZMAT_SPRAY);
        registerItemModel(POTASSIUM_IODIDE);
    }
    
    @SideOnly(Side.CLIENT)
    private static void registerBlockModel(Block block) {
        ModelLoader.setCustomModelResourceLocation(
            Item.getItemFromBlock(block),
            0,
            new ModelResourceLocation(block.getRegistryName(), "inventory")
        );
    }
    
    @SideOnly(Side.CLIENT)
    private static void registerItemModel(Item item) {
        ModelLoader.setCustomModelResourceLocation(
            item,
            0,
            new ModelResourceLocation(item.getRegistryName(), "inventory")
        );
    }
}
