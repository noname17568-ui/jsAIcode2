package com.atomichorizons2026.handlers;

import com.atomichorizons2026.AtomicHorizons2026;
import com.atomichorizons2026.blocks.*;
import com.atomichorizons2026.items.ItemBase;
import com.atomichorizons2026.items.ItemFuelRod;
import com.atomichorizons2026.radiation.IRadiationSource;
import com.atomichorizons2026.tileentities.TileEntitySMRController;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.potion.Potion;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@EventBusSubscriber
public class RegistryHandler {
    
    // ==================== ORES (All Phases) ====================
    public static Block ORE_URANIUM;      // Уран (радиоактивен)
    public static Block ORE_THORIUM;      // Торий
    public static Block ORE_ZIRCONIUM;    // Цирконий
    public static Block ORE_FLUORITE;     // Флюорит (фиолетовое свечение)
    public static Block ORE_SULFUR;       // Сера
    public static Block ORE_LEAD;         // Свинец
    public static Block ORE_BERYLLIUM;    // Бериллий
    public static Block ORE_BORON;        // Бор
    public static Block ORE_GRAPHITE;     // Графит
    public static Block ORE_RADIUM;       // Радий (радиоактивен, светится)
    public static Block ORE_MONAZITE;     // Моназит (торий + редкоземельные)
    
    // ==================== BLOCKS (Storage & Construction) ====================
    public static Block BLOCK_GRAPHITE;
    public static Block BLOCK_LEAD;
    public static Block BLOCK_STEEL;
    public static Block BLOCK_CONCRETE;
    public static Block BLOCK_REINFORCED_CONCRETE;
    public static Block BLOCK_RADIUM;     // Светящийся блок радия
    
    // ==================== LEGACY (Phase 1-2) ====================
    public static Block SMR_CORE;
    public static Block SMR_CASING;
    public static Block SMR_CONTROLLER;
    public static Block SMR_HOUSING;
    public static Block SMR_PORT;
    public static Block SMR_GLASS;
    public static Block CORIUM;
    
    // ==================== ITEMS (Materials) ====================
    public static Item RAW_URANIUM;
    public static Item RAW_THORIUM;
    public static Item RAW_ZIRCONIUM;
    public static Item RAW_FLUORITE;
    public static Item RAW_SULFUR;
    public static Item RAW_LEAD;
    public static Item RAW_BERYLLIUM;
    public static Item RAW_BORON;
    public static Item RAW_GRAPHITE;
    public static Item RAW_RADIUM;
    
    public static Item INGOT_URANIUM;
    public static Item INGOT_THORIUM;
    public static Item INGOT_ZIRCONIUM;
    public static Item INGOT_LEAD;
    public static Item INGOT_STEEL;
    public static Item INGOT_BERYLLIUM;
    public static Item INGOT_BORON;
    public static Item INGOT_GRAPHITE;
    public static Item INGOT_RADIUM;
    
    // ==================== ITEMS (Nuclear) ====================
    public static Item HALEU;
    public static Item TRISO_PARTICLES;
    public static Item FUEL_ROD_HALEU_LEGACY;
    public static Item FUEL_ROD;
    public static Item SPENT_FUEL_ROD;
    public static Item YELLOWCAKE;
    public static Item URANIUM_HEXAFLUORIDE;
    
    // ==================== ITEMS (Tools & Consumables) ====================
    public static Item HAZMAT_SPRAY;
    public static Item POTASSIUM_IODIDE;
    public static Item RADAWAY;
    public static Item RADX;
    public static Item GEIGER_COUNTER;
    public static Item DOSIMETER;
    
    // ==================== POTIONS ====================
    public static Potion POTION_RADIATION;
    
    public static void preInitRegistries() {
        // ==================== ORES ====================
        // Уран - радиоактивен (5 Rad/t), глубоко под землей
        ORE_URANIUM = new BlockRadioactiveOre("ore_uranium", 3, 15.0f, 5, 
            5.0, IRadiationSource.RadiationType.GAMMA, 3.0);
        
        // Торий - менее радиоактивен
        ORE_THORIUM = new BlockRadioactiveOre("ore_thorium", 3, 12.0f, 3,
            1.0, IRadiationSource.RadiationType.ALPHA, 2.0);
        
        // Цирконий
        ORE_ZIRCONIUM = new BlockOre("ore_zirconium", 2, 10.0f, 2);
        
        // Флюорит - фиолетовое свечение
        ORE_FLUORITE = new BlockOre("ore_fluorite", 2, 8.0f, 3) {
            @Override
            public int getLightValue(IBlockState state) {
                return 5; // Слабое свечение
            }
        };
        
        // Сера
        ORE_SULFUR = new BlockOre("ore_sulfur", 1, 6.0f, 2);
        
        // Свинец
        ORE_LEAD = new BlockOre("ore_lead", 2, 8.0f, 2);
        
        // Бериллий
        ORE_BERYLLIUM = new BlockOre("ore_beryllium", 3, 12.0f, 4);
        
        // Бор
        ORE_BORON = new BlockOre("ore_boron", 2, 9.0f, 2);
        
        // Графит
        ORE_GRAPHITE = new BlockOre("ore_graphite", 1, 5.0f, 1);
        
        // Радий - сильно радиоактивен, светится
        ORE_RADIUM = new BlockRadioactiveOre("ore_radium", 3, 20.0f, 10,
            50.0, IRadiationSource.RadiationType.GAMMA, 5.0) {
            @Override
            public int getLightValue(IBlockState state) {
                return 15; // Максимальное свечение
            }
        };
        
        // Моназит - песчаная руда (генерируется в песке)
        ORE_MONAZITE = new BlockOre("ore_monazite", 2, 7.0f, 3);
        
        // ==================== STORAGE BLOCKS ====================
        BLOCK_GRAPHITE = new BlockBase("block_graphite", Material.IRON, 5.0f, 2);
        BLOCK_LEAD = new BlockBase("block_lead", Material.IRON, 8.0f, 2);
        BLOCK_STEEL = new BlockBase("block_steel", Material.IRON, 10.0f, 2);
        BLOCK_CONCRETE = new BlockBase("block_concrete", Material.ROCK, 50.0f, 2);
        BLOCK_REINFORCED_CONCRETE = new BlockBase("block_reinforced_concrete", Material.IRON, 100.0f, 3);
        
        // Блок радия - сильно светится и радиоактивен
        BLOCK_RADIUM = new BlockRadioactiveOre("block_radium", 3, 20.0f, 0,
            200.0, IRadiationSource.RadiationType.GAMMA, 10.0) {
            @Override
            public int getLightValue(IBlockState state) {
                return 15;
            }
        };
        
        // ==================== LEGACY SMR BLOCKS ====================
        SMR_CORE = new BlockSMRCore("smr_core");
        SMR_CASING = new BlockBase("smr_casing", Material.IRON, 15.0f, 2);
        SMR_CONTROLLER = new BlockSMRController("smr_controller");
        SMR_HOUSING = new BlockSMRHousing("smr_housing");
        SMR_PORT = new BlockSMRPort("smr_port");
        SMR_GLASS = new BlockSMRGlass("smr_glass");
        CORIUM = new BlockCorium("corium");
        
        // ==================== ITEMS (Raw Materials) ====================
        RAW_URANIUM = new ItemBase("raw_uranium");
        RAW_THORIUM = new ItemBase("raw_thorium");
        RAW_ZIRCONIUM = new ItemBase("raw_zirconium");
        RAW_FLUORITE = new ItemBase("raw_fluorite");
        RAW_SULFUR = new ItemBase("raw_sulfur");
        RAW_LEAD = new ItemBase("raw_lead");
        RAW_BERYLLIUM = new ItemBase("raw_beryllium");
        RAW_BORON = new ItemBase("raw_boron");
        RAW_GRAPHITE = new ItemBase("raw_graphite");
        RAW_RADIUM = new ItemBase("raw_radium");
        
        // ==================== ITEMS (Ingots) ====================
        INGOT_URANIUM = new ItemBase("ingot_uranium");
        INGOT_THORIUM = new ItemBase("ingot_thorium");
        INGOT_ZIRCONIUM = new ItemBase("ingot_zirconium");
        INGOT_LEAD = new ItemBase("ingot_lead");
        INGOT_STEEL = new ItemBase("ingot_steel");
        INGOT_BERYLLIUM = new ItemBase("ingot_beryllium");
        INGOT_BORON = new ItemBase("ingot_boron");
        INGOT_GRAPHITE = new ItemBase("ingot_graphite");
        INGOT_RADIUM = new ItemBase("ingot_radium");
        
        // ==================== ITEMS (Nuclear) ====================
        HALEU = new ItemBase("haleu");
        TRISO_PARTICLES = new ItemBase("triso_particles");
        FUEL_ROD_HALEU_LEGACY = new ItemBase("fuel_rod_haleu");
        FUEL_ROD = new ItemFuelRod("fuel_rod");
        SPENT_FUEL_ROD = new ItemBase("spent_fuel_rod");
        YELLOWCAKE = new ItemBase("yellowcake");
        URANIUM_HEXAFLUORIDE = new ItemBase("uranium_hexafluoride");
        
        // ==================== ITEMS (Consumables) ====================
        HAZMAT_SPRAY = new ItemBase("hazmat_spray");
        POTASSIUM_IODIDE = new ItemBase("potassium_iodide");
        RADAWAY = new ItemBase("radaway");
        RADX = new ItemBase("radx");
        
        // ==================== ITEMS (Tools) ====================
        // GEIGER_COUNTER = new ItemGeigerCounter("geiger_counter");
        // DOSIMETER = new ItemDosimeter("dosimeter");
        
        // ==================== Potions ====================
        // POTION_RADIATION = new PotionRadiation();
    }
    
    public static void initRegistries() {
        // Register recipes here
    }
    
    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll(
            // ORES
            ORE_URANIUM, ORE_THORIUM, ORE_ZIRCONIUM, ORE_FLUORITE,
            ORE_SULFUR, ORE_LEAD, ORE_BERYLLIUM, ORE_BORON,
            ORE_GRAPHITE, ORE_RADIUM, ORE_MONAZITE,
            // STORAGE
            BLOCK_GRAPHITE, BLOCK_LEAD, BLOCK_STEEL,
            BLOCK_CONCRETE, BLOCK_REINFORCED_CONCRETE, BLOCK_RADIUM,
            // SMR
            SMR_CORE, SMR_CASING, SMR_CONTROLLER, SMR_HOUSING,
            SMR_PORT, SMR_GLASS, CORIUM
        );
        
        // Register tile entities
        GameRegistry.registerTileEntity(((BlockSMRCore)SMR_CORE).getTileEntityClass(), SMR_CORE.getRegistryName());
        GameRegistry.registerTileEntity(TileEntitySMRController.class, SMR_CONTROLLER.getRegistryName());
    }
    
    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        // Register item blocks
        event.getRegistry().registerAll(
            // ORES
            new ItemBlock(ORE_URANIUM).setRegistryName(ORE_URANIUM.getRegistryName()),
            new ItemBlock(ORE_THORIUM).setRegistryName(ORE_THORIUM.getRegistryName()),
            new ItemBlock(ORE_ZIRCONIUM).setRegistryName(ORE_ZIRCONIUM.getRegistryName()),
            new ItemBlock(ORE_FLUORITE).setRegistryName(ORE_FLUORITE.getRegistryName()),
            new ItemBlock(ORE_SULFUR).setRegistryName(ORE_SULFUR.getRegistryName()),
            new ItemBlock(ORE_LEAD).setRegistryName(ORE_LEAD.getRegistryName()),
            new ItemBlock(ORE_BERYLLIUM).setRegistryName(ORE_BERYLLIUM.getRegistryName()),
            new ItemBlock(ORE_BORON).setRegistryName(ORE_BORON.getRegistryName()),
            new ItemBlock(ORE_GRAPHITE).setRegistryName(ORE_GRAPHITE.getRegistryName()),
            new ItemBlock(ORE_RADIUM).setRegistryName(ORE_RADIUM.getRegistryName()),
            new ItemBlock(ORE_MONAZITE).setRegistryName(ORE_MONAZITE.getRegistryName()),
            // STORAGE
            new ItemBlock(BLOCK_GRAPHITE).setRegistryName(BLOCK_GRAPHITE.getRegistryName()),
            new ItemBlock(BLOCK_LEAD).setRegistryName(BLOCK_LEAD.getRegistryName()),
            new ItemBlock(BLOCK_STEEL).setRegistryName(BLOCK_STEEL.getRegistryName()),
            new ItemBlock(BLOCK_CONCRETE).setRegistryName(BLOCK_CONCRETE.getRegistryName()),
            new ItemBlock(BLOCK_REINFORCED_CONCRETE).setRegistryName(BLOCK_REINFORCED_CONCRETE.getRegistryName()),
            new ItemBlock(BLOCK_RADIUM).setRegistryName(BLOCK_RADIUM.getRegistryName()),
            // SMR
            new ItemBlock(SMR_CORE).setRegistryName(SMR_CORE.getRegistryName()),
            new ItemBlock(SMR_CASING).setRegistryName(SMR_CASING.getRegistryName()),
            new ItemBlock(SMR_CONTROLLER).setRegistryName(SMR_CONTROLLER.getRegistryName()),
            new ItemBlock(SMR_HOUSING).setRegistryName(SMR_HOUSING.getRegistryName()),
            new ItemBlock(SMR_PORT).setRegistryName(SMR_PORT.getRegistryName()),
            new ItemBlock(SMR_GLASS).setRegistryName(SMR_GLASS.getRegistryName()),
            new ItemBlock(CORIUM).setRegistryName(CORIUM.getRegistryName())
        );
        
        // Register items
        event.getRegistry().registerAll(
            // RAW
            RAW_URANIUM, RAW_THORIUM, RAW_ZIRCONIUM, RAW_FLUORITE,
            RAW_SULFUR, RAW_LEAD, RAW_BERYLLIUM, RAW_BORON,
            RAW_GRAPHITE, RAW_RADIUM,
            // INGOTS
            INGOT_URANIUM, INGOT_THORIUM, INGOT_ZIRCONIUM, INGOT_LEAD,
            INGOT_STEEL, INGOT_BERYLLIUM, INGOT_BORON, INGOT_GRAPHITE, INGOT_RADIUM,
            // NUCLEAR
            HALEU, TRISO_PARTICLES, FUEL_ROD_HALEU_LEGACY, FUEL_ROD,
            SPENT_FUEL_ROD, YELLOWCAKE, URANIUM_HEXAFLUORIDE,
            // CONSUMABLES
            HAZMAT_SPRAY, POTASSIUM_IODIDE, RADAWAY, RADX
        );
    }
    
    @SubscribeEvent
    public static void registerPotions(RegistryEvent.Register<Potion> event) {
        if (POTION_RADIATION != null) {
            event.getRegistry().register(POTION_RADIATION);
        }
    }
    
    @SideOnly(Side.CLIENT)
    public static void registerModels() {
        // ==================== ORES ====================
        registerBlockModel(ORE_URANIUM);
        registerBlockModel(ORE_THORIUM);
        registerBlockModel(ORE_ZIRCONIUM);
        registerBlockModel(ORE_FLUORITE);
        registerBlockModel(ORE_SULFUR);
        registerBlockModel(ORE_LEAD);
        registerBlockModel(ORE_BERYLLIUM);
        registerBlockModel(ORE_BORON);
        registerBlockModel(ORE_GRAPHITE);
        registerBlockModel(ORE_RADIUM);
        registerBlockModel(ORE_MONAZITE);
        
        // ==================== STORAGE ====================
        registerBlockModel(BLOCK_GRAPHITE);
        registerBlockModel(BLOCK_LEAD);
        registerBlockModel(BLOCK_STEEL);
        registerBlockModel(BLOCK_CONCRETE);
        registerBlockModel(BLOCK_REINFORCED_CONCRETE);
        registerBlockModel(BLOCK_RADIUM);
        
        // ==================== SMR ====================
        registerBlockModel(SMR_CORE);
        registerBlockModel(SMR_CASING);
        registerBlockModel(SMR_CONTROLLER);
        registerBlockModel(SMR_HOUSING);
        registerBlockModel(SMR_PORT);
        registerBlockModel(SMR_GLASS);
        registerBlockModel(CORIUM);
        
        // ==================== ITEMS (RAW) ====================
        registerItemModel(RAW_URANIUM);
        registerItemModel(RAW_THORIUM);
        registerItemModel(RAW_ZIRCONIUM);
        registerItemModel(RAW_FLUORITE);
        registerItemModel(RAW_SULFUR);
        registerItemModel(RAW_LEAD);
        registerItemModel(RAW_BERYLLIUM);
        registerItemModel(RAW_BORON);
        registerItemModel(RAW_GRAPHITE);
        registerItemModel(RAW_RADIUM);
        
        // ==================== ITEMS (INGOTS) ====================
        registerItemModel(INGOT_URANIUM);
        registerItemModel(INGOT_THORIUM);
        registerItemModel(INGOT_ZIRCONIUM);
        registerItemModel(INGOT_LEAD);
        registerItemModel(INGOT_STEEL);
        registerItemModel(INGOT_BERYLLIUM);
        registerItemModel(INGOT_BORON);
        registerItemModel(INGOT_GRAPHITE);
        registerItemModel(INGOT_RADIUM);
        
        // ==================== ITEMS (NUCLEAR) ====================
        registerItemModel(HALEU);
        registerItemModel(TRISO_PARTICLES);
        registerItemModel(FUEL_ROD_HALEU_LEGACY);
        registerItemModel(FUEL_ROD);
        registerItemModel(SPENT_FUEL_ROD);
        registerItemModel(YELLOWCAKE);
        registerItemModel(URANIUM_HEXAFLUORIDE);
        
        // ==================== ITEMS (CONSUMABLES) ====================
        registerItemModel(HAZMAT_SPRAY);
        registerItemModel(POTASSIUM_IODIDE);
        registerItemModel(RADAWAY);
        registerItemModel(RADX);
    }
    
    @SideOnly(Side.CLIENT)
    private static void registerBlockModel(Block block) {
        ModelLoader.setCustomModelResourceLocation(
            Item.getItemFromBlock(block),
            0,
            new ModelResourceLocation(block.getRegistryName(), "inventory")
        );
    }
    
    @SideOnly(Side.CLIENT)
    private static void registerItemModel(Item item) {
        ModelLoader.setCustomModelResourceLocation(
            item,
            0,
            new ModelResourceLocation(item.getRegistryName(), "inventory")
        );
    }
}
