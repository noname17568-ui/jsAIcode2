package com.atomichorizons2026.handlers;

import com.atomichorizons2026.AtomicHorizons2026;
import com.atomichorizons2026.blocks.*;
import com.atomichorizons2026.items.ItemBase;
import com.atomichorizons2026.items.ItemFuelRod;
import com.atomichorizons2026.tileentities.TileEntitySMRController;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.potion.Potion;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@EventBusSubscriber
public class RegistryHandler {
    
    // ==================== BLOCKS (Phase 1) ====================
    public static Block ORE_URANIUM;
    public static Block ORE_THORIUM;
    public static Block ORE_ZIRCONIUM;
    public static Block BLOCK_GRAPHITE;
    public static Block BLOCK_LEAD;
    public static Block BLOCK_STEEL;
    public static Block SMR_CORE; // Legacy (Phase 1)
    public static Block SMR_CASING; // Legacy (Phase 1)
    
    // ==================== BLOCKS (Phase 2 - Multiblock) ====================
    public static Block SMR_CONTROLLER;
    public static Block SMR_HOUSING;
    public static Block SMR_PORT;
    public static Block SMR_GLASS;
    public static Block CORIUM;
    
    // ==================== ITEMS (Phase 1) ====================
    public static Item RAW_URANIUM;
    public static Item HALEU;
    public static Item TRISO_PARTICLES;
    public static Item INGOT_THORIUM;
    public static Item INGOT_ZIRCONIUM;
    public static Item INGOT_LEAD;
    public static Item INGOT_STEEL;
    public static Item INGOT_GRAPHITE;
    public static Item FUEL_ROD_HALEU_LEGACY; // Legacy
    public static Item SPENT_FUEL_ROD;
    public static Item HAZMAT_SPRAY;
    public static Item POTASSIUM_IODIDE;
    
    // ==================== ITEMS (Phase 2) ====================
    public static Item FUEL_ROD; // Новый с прочностью
    
    // ==================== POTIONS ====================
    public static Potion POTION_RADIATION;
    
    public static void preInitRegistries() {
        // ==================== Phase 1 Blocks ====================
        ORE_URANIUM = new BlockOre("ore_uranium", 3, 15.0f, 3);
        ORE_THORIUM = new BlockOre("ore_thorium", 3, 12.0f, 3);
        ORE_ZIRCONIUM = new BlockOre("ore_zirconium", 2, 10.0f, 2);
        BLOCK_GRAPHITE = new BlockBase("block_graphite", Material.IRON, 5.0f, 2);
        BLOCK_LEAD = new BlockBase("block_lead", Material.IRON, 8.0f, 2);
        BLOCK_STEEL = new BlockBase("block_steel", Material.IRON, 10.0f, 2);
        SMR_CORE = new BlockSMRCore("smr_core");
        SMR_CASING = new BlockBase("smr_casing", Material.IRON, 15.0f, 2);
        
        // ==================== Phase 2 Blocks (Multiblock) ====================
        SMR_CONTROLLER = new BlockSMRController("smr_controller");
        SMR_HOUSING = new BlockSMRHousing("smr_housing");
        SMR_PORT = new BlockSMRPort("smr_port");
        SMR_GLASS = new BlockSMRGlass("smr_glass");
        CORIUM = new BlockCorium("corium");
        
        // ==================== Phase 1 Items ====================
        RAW_URANIUM = new ItemBase("raw_uranium");
        HALEU = new ItemBase("haleu");
        TRISO_PARTICLES = new ItemBase("triso_particles");
        INGOT_THORIUM = new ItemBase("ingot_thorium");
        INGOT_ZIRCONIUM = new ItemBase("ingot_zirconium");
        INGOT_LEAD = new ItemBase("ingot_lead");
        INGOT_STEEL = new ItemBase("ingot_steel");
        INGOT_GRAPHITE = new ItemBase("ingot_graphite");
        FUEL_ROD_HALEU_LEGACY = new ItemBase("fuel_rod_haleu");
        SPENT_FUEL_ROD = new ItemBase("spent_fuel_rod");
        HAZMAT_SPRAY = new ItemBase("hazmat_spray");
        POTASSIUM_IODIDE = new ItemBase("potassium_iodide");
        
        // ==================== Phase 2 Items ====================
        FUEL_ROD = new ItemFuelRod("fuel_rod");
        
        // ==================== Potions ====================
        // POTION_RADIATION = new PotionRadiation(); // Раскомментировать при создании
    }
    
    public static void initRegistries() {
        // Register recipes here
    }
    
    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll(
            // Phase 1
            ORE_URANIUM,
            ORE_THORIUM,
            ORE_ZIRCONIUM,
            BLOCK_GRAPHITE,
            BLOCK_LEAD,
            BLOCK_STEEL,
            SMR_CORE,
            SMR_CASING,
            // Phase 2
            SMR_CONTROLLER,
            SMR_HOUSING,
            SMR_PORT,
            SMR_GLASS,
            CORIUM
        );
        
        // Register tile entities
        GameRegistry.registerTileEntity(((BlockSMRCore)SMR_CORE).getTileEntityClass(), SMR_CORE.getRegistryName());
        GameRegistry.registerTileEntity(TileEntitySMRController.class, SMR_CONTROLLER.getRegistryName());
    }
    
    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        // Register item blocks
        event.getRegistry().registerAll(
            // Phase 1
            new ItemBlock(ORE_URANIUM).setRegistryName(ORE_URANIUM.getRegistryName()),
            new ItemBlock(ORE_THORIUM).setRegistryName(ORE_THORIUM.getRegistryName()),
            new ItemBlock(ORE_ZIRCONIUM).setRegistryName(ORE_ZIRCONIUM.getRegistryName()),
            new ItemBlock(BLOCK_GRAPHITE).setRegistryName(BLOCK_GRAPHITE.getRegistryName()),
            new ItemBlock(BLOCK_LEAD).setRegistryName(BLOCK_LEAD.getRegistryName()),
            new ItemBlock(BLOCK_STEEL).setRegistryName(BLOCK_STEEL.getRegistryName()),
            new ItemBlock(SMR_CORE).setRegistryName(SMR_CORE.getRegistryName()),
            new ItemBlock(SMR_CASING).setRegistryName(SMR_CASING.getRegistryName()),
            // Phase 2
            new ItemBlock(SMR_CONTROLLER).setRegistryName(SMR_CONTROLLER.getRegistryName()),
            new ItemBlock(SMR_HOUSING).setRegistryName(SMR_HOUSING.getRegistryName()),
            new ItemBlock(SMR_PORT).setRegistryName(SMR_PORT.getRegistryName()),
            new ItemBlock(SMR_GLASS).setRegistryName(SMR_GLASS.getRegistryName()),
            new ItemBlock(CORIUM).setRegistryName(CORIUM.getRegistryName())
        );
        
        // Register items
        event.getRegistry().registerAll(
            // Phase 1
            RAW_URANIUM,
            HALEU,
            TRISO_PARTICLES,
            INGOT_THORIUM,
            INGOT_ZIRCONIUM,
            INGOT_LEAD,
            INGOT_STEEL,
            INGOT_GRAPHITE,
            FUEL_ROD_HALEU_LEGACY,
            SPENT_FUEL_ROD,
            HAZMAT_SPRAY,
            POTASSIUM_IODIDE,
            // Phase 2
            FUEL_ROD
        );
    }
    
    @SubscribeEvent
    public static void registerPotions(RegistryEvent.Register<Potion> event) {
        if (POTION_RADIATION != null) {
            event.getRegistry().register(POTION_RADIATION);
        }
    }
    
    @SideOnly(Side.CLIENT)
    public static void registerModels() {
        // ==================== Block Models ====================
        // Phase 1
        registerBlockModel(ORE_URANIUM);
        registerBlockModel(ORE_THORIUM);
        registerBlockModel(ORE_ZIRCONIUM);
        registerBlockModel(BLOCK_GRAPHITE);
        registerBlockModel(BLOCK_LEAD);
        registerBlockModel(BLOCK_STEEL);
        registerBlockModel(SMR_CORE);
        registerBlockModel(SMR_CASING);
        // Phase 2
        registerBlockModel(SMR_CONTROLLER);
        registerBlockModel(SMR_HOUSING);
        registerBlockModel(SMR_PORT);
        registerBlockModel(SMR_GLASS);
        registerBlockModel(CORIUM);
        
        // ==================== Item Models ====================
        // Phase 1
        registerItemModel(RAW_URANIUM);
        registerItemModel(HALEU);
        registerItemModel(TRISO_PARTICLES);
        registerItemModel(INGOT_THORIUM);
        registerItemModel(INGOT_ZIRCONIUM);
        registerItemModel(INGOT_LEAD);
        registerItemModel(INGOT_STEEL);
        registerItemModel(INGOT_GRAPHITE);
        registerItemModel(FUEL_ROD_HALEU_LEGACY);
        registerItemModel(SPENT_FUEL_ROD);
        registerItemModel(HAZMAT_SPRAY);
        registerItemModel(POTASSIUM_IODIDE);
        // Phase 2
        registerItemModel(FUEL_ROD);
    }
    
    @SideOnly(Side.CLIENT)
    private static void registerBlockModel(Block block) {
        ModelLoader.setCustomModelResourceLocation(
            Item.getItemFromBlock(block),
            0,
            new ModelResourceLocation(block.getRegistryName(), "inventory")
        );
    }
    
    @SideOnly(Side.CLIENT)
    private static void registerItemModel(Item item) {
        ModelLoader.setCustomModelResourceLocation(
            item,
            0,
            new ModelResourceLocation(item.getRegistryName(), "inventory")
        );
    }
}
